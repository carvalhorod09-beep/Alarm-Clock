package com.example.bluetooth_alarm_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
