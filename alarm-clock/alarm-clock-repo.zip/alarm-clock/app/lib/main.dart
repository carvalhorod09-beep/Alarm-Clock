import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';

void main() {
  runApp(const MyApp());
}

enum BleState { disconnected, scanning, connecting, ready }

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int currentIndex = 0;

  BluetoothDevice? device;
  BluetoothCharacteristic? uart;

  BleState bleState = BleState.disconnected;

  List<ScanResult> devices = [];
  StreamSubscription? scanSub;

  List<Map<String, dynamic>> alarms = [];

  String deviceName = "Not Connected";

  Color statusColor() {
    switch (bleState) {
      case BleState.ready:
        return Colors.green;
      case BleState.connecting:
        return Colors.orange;
      case BleState.scanning:
        return Colors.blue;
      case BleState.disconnected:
      default:
        return Colors.red;
    }
  }

  String statusText() {
    switch (bleState) {
      case BleState.ready:
        return "Connected";
      case BleState.connecting:
        return "Connecting...";
      case BleState.scanning:
        return "Scanning...";
      case BleState.disconnected:
      default:
        return "Disconnected";
    }
  }

  Future<void> connect(BluetoothDevice d) async {
    await FlutterBluePlus.stopScan();

    setState(() {
      bleState = BleState.connecting;
      deviceName = d.platformName.isEmpty ? "Device" : d.platformName;
    });

    await d.connect(timeout: const Duration(seconds: 10));

    device = d;
    await discoverUART();

    setState(() => bleState = BleState.ready);
  }

  Future<void> discoverUART() async {
    var services = await device!.discoverServices();

    for (var s in services) {
      for (var c in s.characteristics) {
        if (c.properties.writeWithoutResponse) {
          uart = c;
        }
      }
    }
  }

  Future<void> send(String cmd) async {
    if (uart == null) return;

    await uart!.write(
      utf8.encode("$cmd#"),
      withoutResponse: true,
    );
  }

  Future<void> addAlarm() async {
    final t = await showTimePicker(
      context: context,
      initialTime: const TimeOfDay(hour: 7, minute: 30),
    );

    if (t == null) return;

    alarms.add({
      "hour": t.hour,
      "minute": t.minute,
    });

    await send(
      "A${t.hour.toString().padLeft(2, '0')}"
      "${t.minute.toString().padLeft(2, '0')}",
    );

    setState(() {});
  }

  Future<void> deleteAll() async {
    await send("DA");
    alarms.clear();
    setState(() {});
  }

  Future<void> scan() async {
    await FlutterBluePlus.stopScan();

    setState(() => bleState = BleState.scanning);

    await FlutterBluePlus.startScan(timeout: const Duration(seconds: 5));

    scanSub?.cancel();
    scanSub = FlutterBluePlus.scanResults.listen((r) {
      setState(() => devices = r);
    });

    setState(() => bleState = BleState.disconnected);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: currentIndex == 0 ? alarmScreen() : bluetoothScreen(),
      bottomNavigationBar: NavigationBar(
        selectedIndex: currentIndex,
        onDestinationSelected: (i) => setState(() => currentIndex = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.alarm), label: "Alarms"),
          NavigationDestination(icon: Icon(Icons.bluetooth), label: "Bluetooth"),
        ],
      ),
    );
  }

  Widget statusBar() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      color: Colors.black,
      child: Row(
        children: [
          Icon(Icons.circle, color: statusColor(), size: 14),
          const SizedBox(width: 10),
          Text("$deviceName • ${statusText()}"),
        ],
      ),
    );
  }

  Widget alarmScreen() {
    return Scaffold(
      appBar: AppBar(title: const Text("Smart Alarm")),
      floatingActionButton: FloatingActionButton(
        onPressed: addAlarm,
        child: const Icon(Icons.add),
      ),
      body: Column(
        children: [
          statusBar(),

          Expanded(
            child: ListView.builder(
              itemCount: alarms.length,
              itemBuilder: (_, i) {
                final a = alarms[i];

                return Dismissible(
                  key: Key("${a["hour"]}${a["minute"]}"),
                  direction: DismissDirection.endToStart,
                  background: Container(
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.only(right: 20),
                    color: Colors.red,
                    child: const Icon(Icons.delete, color: Colors.white),
                  ),
                  onDismissed: (_) async {
                    await send(
                      "D${a["hour"].toString().padLeft(2, '0')}"
                      "${a["minute"].toString().padLeft(2, '0')}",
                    );

                    alarms.removeAt(i);
                    setState(() {});
                  },
                  child: Card(
                    margin: const EdgeInsets.all(10),
                    child: ListTile(
                      title: Text(
                        "${a["hour"]}:${a["minute"].toString().padLeft(2, '0')}",
                        style: const TextStyle(fontSize: 24),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),

          SafeArea(
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ElevatedButton(onPressed: () => send("M1"), child: const Text("M1")),
                    ElevatedButton(onPressed: () => send("M2"), child: const Text("M2")),
                    ElevatedButton(onPressed: () => send("M3"), child: const Text("M3")),
                  ],
                ),

                const SizedBox(height: 10),

                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                  onPressed: deleteAll,
                  child: const Text("Clear All"),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget bluetoothScreen() {
    return Scaffold(
      appBar: AppBar(title: const Text("Bluetooth")),
      body: Column(
        children: [
          statusBar(),

          ElevatedButton(
            onPressed: scan,
            child: const Text("Scan"),
          ),

          Expanded(
            child: ListView.builder(
              itemCount: devices.length,
              itemBuilder: (_, i) {
                final d = devices[i].device;

                return ListTile(
                  title: Text(
                    d.platformName.isEmpty ? "Device" : d.platformName,
                  ),
                  subtitle: Text(d.remoteId.toString()),
                  onTap: () => connect(d),
                );
              },
            ),
          )
        ],
      ),
    );
  }
}